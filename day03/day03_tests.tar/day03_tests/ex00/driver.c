#include "ft_ft.c"
#include <stdio.h>

int main(void)
{
	int number = 4129459;
	ft_ft(&number);
	printf("%d", number);

	return 0;
}